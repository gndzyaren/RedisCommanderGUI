const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const redisController = require('./redis');
const fs = require('fs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

var path = __dirname + "/";

app.get("/",function(req,res) {
    res.sendFile(path + "index.html");
});

app.post('/runCommand',function(req, res, next) {
    var command = req.body.command || req.query.command || '';
    redisController.sendCommand(command, function(err, result){
        if(err){
            res.status(500).send(result);
        }
        else{
            res.send(result);
        }
    });
});

app.get('/tutorial', function(req, res, next) {
    let path = __dirname + '/tutorial.pdf';
    fs.readFile(path, 'utf-8', function(err, data){
        if(err){
            res.status(500).send({
                message: 'Dosya bulunamadı!'
            });
        }
        else{
            /*
            res.writeHead(200, {
                'Content-Type': 'application/force-download',
                'Content-disposition': 'attachment; filename=redis_tutorial.pdf'
            });
            res.end(data);
            */
            res.contentType('application/pdf');
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'attachment; filename=tutorial.pdf');
            res.download(path, function(err, result){
            })
        }
    });
});


app.listen('3100');
console.log("Server start at port: 3100");