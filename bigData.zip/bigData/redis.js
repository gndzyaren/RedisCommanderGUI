var redis = require('redis');
var client = redis.createClient();

client.on('connect', function() {
    console.log('redis connected');
});


var sendCommand = function(command, callback){
    try{
        console.log("command: ", command);
        let arArgs = command.split(' ');
        let commandName = arArgs[0];
        let args = [];
        for(let i=1; i<arArgs.length; i++){
            args.push(arArgs[i]);
        }
        client.send_command(commandName, args, function(err, data){
            if(err){
                callback(true, {
                    message: 'Hatalı komut girdiniz.'
                })
            }
            else{
                if(data == 'OK'){
                    callback(null, {
                        message: 'İşlem başarıyla tamamlandı.'
                    })
                }
                else{
                    callback(null, {
                        message: data
                    })
                }
            }
        });
    }
    catch(err){
        console.log('unexpected err: ', err);
    }
};

module.exports.sendCommand = sendCommand;